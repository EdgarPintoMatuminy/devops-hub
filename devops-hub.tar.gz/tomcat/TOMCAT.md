# 🐱 Tomcat - Comandos Diarios

## 📍 Ubicaciones Importantes

```bash
# Instalación (típicamente)
/opt/tomcat/
/usr/local/tomcat/
$CATALINA_HOME/

# Binarios y scripts
$CATALINA_HOME/bin/
startup.sh
shutdown.sh
catalina.sh

# Logs
$CATALINA_HOME/logs/
catalina.out
catalina.YYYY-MM-DD.log

# Aplicaciones (webapps)
$CATALINA_HOME/webapps/

# Configuración
$CATALINA_HOME/conf/
server.xml
context.xml
web.xml
```

## 🚀 Inicio y Parada

```bash
# Iniciar Tomcat
$CATALINA_HOME/bin/startup.sh
cd $CATALINA_HOME/bin && ./startup.sh

# Parar Tomcat (graceful shutdown)
$CATALINA_HOME/bin/shutdown.sh

# Parar forzadamente
pkill -f "catalina" 
pkill -9 java

# Reiniciar
$CATALINA_HOME/bin/shutdown.sh
sleep 5
$CATALINA_HOME/bin/startup.sh

# Modo systemd
sudo systemctl start tomcat
sudo systemctl stop tomcat
sudo systemctl restart tomcat
sudo systemctl status tomcat
```

## ✅ Verificación de Estado

```bash
# Verificar procesos
ps aux | grep tomcat
ps aux | grep java

# Puerto de Tomcat (default 8080)
sudo netstat -tlnp | grep 8080
sudo ss -tlnp | grep 8080

# Logs en tiempo real
tail -f $CATALINA_HOME/logs/catalina.out

# Verificar JVM
jps -l

# Test de conexión
curl http://localhost:8080
curl -v http://localhost:8080/
```

## 📦 Gestión de Aplicaciones

```bash
# Listar aplicaciones en webapps
ls -la $CATALINA_HOME/webapps/

# Desplegar aplicación (copiar .war)
cp miapp.war $CATALINA_HOME/webapps/

# Desplegar sin reiniciar (manager app)
curl -u admin:password \
  --upload-file app.war \
  "http://localhost:8080/manager/text/deploy?path=/app"

# Recargar aplicación
curl -u admin:password \
  "http://localhost:8080/manager/text/reload?path=/app"

# Descargar aplicación
curl -u admin:password \
  "http://localhost:8080/manager/text/undeploy?path=/app"

# Lista de aplicaciones vía manager
curl -u admin:password \
  "http://localhost:8080/manager/text/list"
```

## 💾 Gestión de Memoria

```bash
# Configurar memoria en catalina.sh
export CATALINA_OPTS="-Xms512m -Xmx2048m"

# O en setenv.sh
# $CATALINA_HOME/bin/setenv.sh
CATALINA_OPTS="-Xms1024m -Xmx3072m \
  -XX:+UseParallelGC \
  -XX:+PrintGCDetails \
  -XX:+PrintGCTimeStamps \
  -Xloggc:$CATALINA_HOME/logs/gc.log"

# Ver uso de memoria
jstat -gc -h10 $(jps -l | grep Catalina | awk '{print $1}') 1000

# Memory dump
jmap -heap $(jps -l | grep Catalina | awk '{print $1}')

# Monitorar con JConsole
jconsole
```

## 🔍 Logs y Troubleshooting

```bash
# Ver logs principales
tail -n 100 $CATALINA_HOME/logs/catalina.out
tail -f $CATALINA_HOME/logs/catalina.out

# Logs por aplicación
ls -la $CATALINA_HOME/webapps/ROOT/logs/

# Búsqueda en logs
grep "ERROR" $CATALINA_HOME/logs/catalina.out
grep "Exception" $CATALINA_HOME/logs/catalina.out

# Logs de acceso
cat $CATALINA_HOME/logs/localhost_access_log.*.txt

# Últimas líneas con contexto
grep -A 5 -B 5 "ERROR" $CATALINA_HOME/logs/catalina.out

# Timestamps específicos
grep "2024-07-25" $CATALINA_HOME/logs/catalina.out
```

## ⚙️ Configuración server.xml

```xml
<!-- $CATALINA_HOME/conf/server.xml -->

<Connector port="8080" 
           protocol="HTTP/1.1"
           connectionTimeout="20000"
           redirectPort="8443"
           maxConnections="10000"
           maxThreads="200"
           minSpareThreads="50" />

<Connector port="8009" 
           protocol="AJP/1.3"
           redirectPort="8443" />

<!-- Gestor de aplicaciones -->
<Manager pathname="SESSIONS.ser" />

<!-- Logger -->
<Valve className="org.apache.catalina.valves.AccessLogValve"
       directory="logs"
       prefix="localhost_access_log"
       pattern="%h %l %u %t &quot;%r&quot; %s %b" />
```

## 🔌 Conector AJP (para Nginx/Apache)

```xml
<!-- En server.xml, verificar conector AJP en puerto 8009 -->
<Connector protocol="AJP/1.3"
           address="127.0.0.1"
           port="8009"
           redirectPort="8443" />
```

```nginx
# Configuración Nginx (upstream)
upstream tomcat_backend {
    server 127.0.0.1:8080;
}

server {
    listen 80;
    server_name ejemplo.com;
    
    location / {
        proxy_pass http://tomcat_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

## 🛡️ Seguridad

```bash
# Eliminar aplicaciones por defecto
rm -rf $CATALINA_HOME/webapps/docs
rm -rf $CATALINA_HOME/webapps/examples
rm -rf $CATALINA_HOME/webapps/host-manager

# Desactivar manager remoto
# O configurar con IP restringidas en manager.xml

# Cambiar puerto por defecto
# Editar conf/server.xml
# <Connector port="8080" ... /> 
```

## 📊 Monitoreo

```bash
# JVisualVM
jvisualvm &

# JConsole
jconsole &

# Status page (si está habilitado)
curl http://localhost:8080/server-status

# Procesos Java
jps

# Ver opciones JVM de un proceso
jcmd $(jps -l | grep Catalina | awk '{print $1}') VM.command_line
```

## 🐛 Debugging

```bash
# Debug mode en catalina.sh
export CATALINA_OPTS="-agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=5005"

# Iniciar Tomcat
$CATALINA_HOME/bin/startup.sh

# Conectar desde IDE (puerto 5005)
# IDE -> Debug -> Attach to Process -> localhost:5005
```

## 📋 Context.xml Personalizado

```xml
<!-- $CATALINA_HOME/conf/Catalina/localhost/miapp.xml -->
<Context path="/miapp" docBase="miapp.war">
    <!-- Database Connection Pool -->
    <Resource name="jdbc/miapp" 
              auth="Container"
              type="javax.sql.DataSource"
              driverClassName="com.mysql.jdbc.Driver"
              url="jdbc:mysql://localhost:3306/miapp"
              username="user"
              password="pass"
              maxTotal="20"
              maxIdle="10"
              maxWaitMillis="-1" />
    
    <!-- Manager de sesiones -->
    <Manager pathname="SESSIONS.ser" />
</Context>
```

## ⚡ Comandos Útiles Rápidos

```bash
# Restart rápido
$CATALINA_HOME/bin/shutdown.sh -force

# Ver puerto PID
sudo netstat -tlnp | grep 8080

# Kill proceso Tomcat
kill $(ps aux | grep 'catalina' | grep -v grep | awk '{print $2}')

# Rebuild aplicación
rm -rf $CATALINA_HOME/webapps/miapp
cp miapp.war $CATALINA_HOME/webapps/

# Limpiar sesiones
rm -rf $CATALINA_HOME/work/Catalina/localhost/*

# Ver versión
$CATALINA_HOME/bin/catalina.sh version
```

## 📌 Checklist Diario

- [ ] ¿Tomcat está running? `ps aux | grep catalina`
- [ ] ¿Puerto 8080 accesible? `curl http://localhost:8080`
- [ ] ¿Aplicaciones desplegadas? `ls $CATALINA_HOME/webapps/`
- [ ] ¿Sin errores en logs? `tail $CATALINA_HOME/logs/catalina.out`
- [ ] ¿Memoria OK? `jstat -gc $(jps -l | grep Catalina | awk '{print $1}')`
- [ ] ¿Sesiones persistidas? `ls $CATALINA_HOME/work/Catalina/localhost/`
- [ ] ¿Conector AJP activo? `grep 'protocol="AJP' $CATALINA_HOME/conf/server.xml`

---

**Última actualización:** Julio 2026
