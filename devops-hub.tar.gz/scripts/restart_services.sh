#!/bin/bash

##############################################################################
# RESTART_SERVICES.SH - Reinicio controlado de servicios
# Soporta reinicio seguro de Apache, Nginx, Tomcat y WebLogic
# Uso: ./restart_services.sh [apache|nginx|tomcat|weblogic|all]
##############################################################################

set -euo pipefail

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Variables
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
LOG_FILE="/var/log/restart_services.log"
SERVICE="${1:-all}"

# Función de log
log() {
    echo -e "${BLUE}[$(date '+%H:%M:%S')]${NC} $1"
    echo "[$TIMESTAMP] $1" >> "$LOG_FILE"
}

success() {
    echo -e "${GREEN}[✓]${NC} $1"
    echo "[SUCCESS] $1" >> "$LOG_FILE"
}

error() {
    echo -e "${RED}[✗]${NC} $1"
    echo "[ERROR] $1" >> "$LOG_FILE"
}

warning() {
    echo -e "${YELLOW}[!]${NC} $1"
    echo "[WARNING] $1" >> "$LOG_FILE"
}

# Función de confirmación
confirm() {
    local prompt="$1"
    read -p "$prompt (s/n): " -n 1 -r
    echo
    [[ $REPLY =~ ^[Ss]$ ]]
}

##############################################################################
# Reinicio Apache
##############################################################################

restart_apache() {
    log "Reiniciando Apache..."
    
    # Verificar syntax
    if ! sudo apachectl configtest; then
        error "Error en configuración Apache"
        return 1
    fi
    
    # Parar gracefully
    log "Deteniendo Apache gracefully..."
    sudo apachectl graceful-stop || sudo systemctl stop apache2
    sleep 2
    
    # Iniciar
    log "Iniciando Apache..."
    sudo systemctl start apache2
    sleep 3
    
    # Verificar
    if systemctl is-active --quiet apache2; then
        success "Apache reiniciado correctamente"
        return 0
    else
        error "Apache no inició correctamente"
        sudo systemctl status apache2
        return 1
    fi
}

##############################################################################
# Reinicio Nginx
##############################################################################

restart_nginx() {
    log "Reiniciando Nginx..."
    
    # Verificar syntax
    if ! sudo nginx -t; then
        error "Error en configuración Nginx"
        return 1
    fi
    
    # Parar gracefully
    log "Deteniendo Nginx gracefully..."
    sudo systemctl stop nginx || sudo nginx -s stop
    sleep 2
    
    # Iniciar
    log "Iniciando Nginx..."
    sudo systemctl start nginx
    sleep 3
    
    # Verificar
    if systemctl is-active --quiet nginx; then
        success "Nginx reiniciado correctamente"
        return 0
    else
        error "Nginx no inició correctamente"
        sudo systemctl status nginx
        return 1
    fi
}

##############################################################################
# Reinicio Tomcat
##############################################################################

restart_tomcat() {
    local CATALINA_HOME="${CATALINA_HOME:-/opt/tomcat}"
    
    log "Reiniciando Tomcat..."
    
    if [ ! -d "$CATALINA_HOME" ]; then
        error "CATALINA_HOME no encontrado: $CATALINA_HOME"
        return 1
    fi
    
    # Parar gracefully
    log "Deteniendo Tomcat gracefully (60 segundos)..."
    if [ -f "$CATALINA_HOME/bin/shutdown.sh" ]; then
        bash "$CATALINA_HOME/bin/shutdown.sh" || true
        sleep 10
    fi
    
    # Kill si es necesario
    log "Verificando si Tomcat se detuvo..."
    if pgrep -f "catalina" > /dev/null; then
        warning "Tomcat aún corre, matando procesos..."
        pkill -f "catalina" || true
        sleep 5
    fi
    
    # Limpiar estado temporal
    log "Limpiando archivos temporales..."
    rm -rf "$CATALINA_HOME/work/Catalina/localhost"/*
    
    # Iniciar
    log "Iniciando Tomcat..."
    bash "$CATALINA_HOME/bin/startup.sh" || true
    sleep 5
    
    # Verificar
    if pgrep -f "catalina" > /dev/null; then
        success "Tomcat reiniciado correctamente"
        
        # Esperar a que esté listo
        log "Esperando a que Tomcat esté listo..."
        local count=0
        while [ $count -lt 30 ]; do
            if curl -f http://localhost:8080 > /dev/null 2>&1; then
                success "Tomcat está listo"
                return 0
            fi
            sleep 2
            ((count++))
        done
        
        return 0
    else
        error "Tomcat no inició correctamente"
        tail -20 "$CATALINA_HOME/logs/catalina.out"
        return 1
    fi
}

##############################################################################
# Reinicio WebLogic
##############################################################################

restart_weblogic() {
    log "Reiniciando WebLogic..."
    
    local DOMAIN_HOME="${DOMAIN_HOME:-}"
    
    if [ -z "$DOMAIN_HOME" ]; then
        error "DOMAIN_HOME no definido"
        return 1
    fi
    
    if [ ! -d "$DOMAIN_HOME" ]; then
        error "DOMAIN_HOME no encontrado: $DOMAIN_HOME"
        return 1
    fi
    
    # Parar gracefully
    log "Deteniendo WebLogic Admin Server..."
    if [ -f "$DOMAIN_HOME/bin/stopWebLogic.sh" ]; then
        bash "$DOMAIN_HOME/bin/stopWebLogic.sh" || true
        sleep 10
    fi
    
    # Kill si es necesario
    if pgrep -f "weblogic.Server" > /dev/null; then
        warning "WebLogic aún corre, matando..."
        pkill -f "weblogic.Server" || true
        sleep 5
    fi
    
    # Iniciar
    log "Iniciando WebLogic Admin Server..."
    nohup bash "$DOMAIN_HOME/bin/startWebLogic.sh" > \
        "$DOMAIN_HOME/startWebLogic.log" 2>&1 &
    
    sleep 10
    
    # Verificar
    local count=0
    while [ $count -lt 60 ]; do
        if curl -f http://localhost:7001 > /dev/null 2>&1; then
            success "WebLogic reiniciado correctamente"
            return 0
        fi
        log "Esperando a WebLogic... ($((count+10))s)"
        sleep 10
        ((count+=10))
    done
    
    error "WebLogic no respondió después de 60 segundos"
    tail -20 "$DOMAIN_HOME/AdminServer.log"
    return 1
}

##############################################################################
# Reinicio Coordenado
##############################################################################

restart_all() {
    log "════════════════════════════════════════"
    log "REINICIO COORDENADO DE TODOS LOS SERVICIOS"
    log "════════════════════════════════════════"
    
    if ! confirm "¿Reiniciar TODOS los servicios?"; then
        log "Operación cancelada"
        return 1
    fi
    
    local failed=0
    
    log "Paso 1: Reiniciando WebLogic (aplicaciones)..."
    restart_weblogic || ((failed++))
    sleep 5
    
    log "Paso 2: Reiniciando Tomcat..."
    restart_tomcat || ((failed++))
    sleep 5
    
    log "Paso 3: Reiniciando Nginx..."
    restart_nginx || ((failed++))
    sleep 5
    
    log "Paso 4: Reiniciando Apache..."
    restart_apache || ((failed++))
    
    echo ""
    if [ $failed -eq 0 ]; then
        success "Todos los servicios reiniciados correctamente"
        return 0
    else
        error "$failed servicio(s) fallaron"
        return 1
    fi
}

##############################################################################
# Main
##############################################################################

main() {
    touch "$LOG_FILE"
    
    echo -e "${BLUE}🔄 SISTEMA DE REINICIO DE SERVICIOS${NC}"
    echo "Timestamp: $TIMESTAMP"
    echo "Servicio: $SERVICE"
    echo ""
    
    case "$SERVICE" in
        apache)
            restart_apache
            ;;
        nginx)
            restart_nginx
            ;;
        tomcat)
            restart_tomcat
            ;;
        weblogic)
            restart_weblogic
            ;;
        all)
            restart_all
            ;;
        *)
            echo "Uso: $0 [apache|nginx|tomcat|weblogic|all]"
            exit 1
            ;;
    esac
    
    local exit_code=$?
    
    echo ""
    if [ $exit_code -eq 0 ]; then
        echo -e "${GREEN}✓ Reinicio completado exitosamente${NC}"
    else
        echo -e "${RED}✗ Reinicio con errores${NC}"
        echo "Revisar log: $LOG_FILE"
    fi
    
    exit $exit_code
}

main "$@"
