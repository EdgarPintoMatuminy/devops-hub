#!/bin/bash

##############################################################################
# HEALTHCHECK.SH - Script de verificación de salud de servicios
# Verifica Apache, Nginx, Tomcat y WebLogic
# Uso: ./healthcheck.sh [--email admin@example.com] [--slack webhook-url]
##############################################################################

set -euo pipefail

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Variables
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
LOG_FILE="/var/log/healthcheck.log"
ALERT_EMAIL="${1:-}"
SLACK_WEBHOOK="${2:-}"

# Inicializa resultado
ISSUES=0

##############################################################################
# Funciones de utilidad
##############################################################################

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
    echo "[$TIMESTAMP] [INFO] $1" >> "$LOG_FILE"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
    echo "[$TIMESTAMP] [SUCCESS] $1" >> "$LOG_FILE"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
    echo "[$TIMESTAMP] [ERROR] $1" >> "$LOG_FILE"
    ((ISSUES++))
}

log_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
    echo "[$TIMESTAMP] [WARNING] $1" >> "$LOG_FILE"
}

send_alert() {
    local subject="$1"
    local message="$2"
    
    if [ -n "$ALERT_EMAIL" ]; then
        echo "$message" | mail -s "$subject" "$ALERT_EMAIL"
    fi
    
    if [ -n "$SLACK_WEBHOOK" ]; then
        curl -X POST "$SLACK_WEBHOOK" \
            -H 'Content-type: application/json' \
            --data "{\"text\": \"$subject\n$message\"}" 2>/dev/null
    fi
}

##############################################################################
# Verificaciones Apache
##############################################################################

check_apache() {
    echo ""
    log_info "Verificando Apache..."
    
    # ¿Está corriendo?
    if systemctl is-active --quiet apache2; then
        log_success "Apache está corriendo"
    else
        log_error "Apache NO está corriendo"
        send_alert "❌ Apache Down" "Apache no está ejecutándose en $(hostname)"
        return 1
    fi
    
    # ¿Config válida?
    if sudo apachectl configtest 2>/dev/null | grep -q "Syntax OK"; then
        log_success "Configuración Apache válida"
    else
        log_error "Configuración Apache inválida"
        sudo apachectl configtest 2>&1 | grep -E "error|Error" >> "$LOG_FILE"
    fi
    
    # ¿Puerto accesible?
    if curl -f http://localhost:80 > /dev/null 2>&1; then
        log_success "Puerto 80 accesible"
    else
        log_error "Puerto 80 NO accesible"
    fi
    
    return 0
}

##############################################################################
# Verificaciones Nginx
##############################################################################

check_nginx() {
    echo ""
    log_info "Verificando Nginx..."
    
    # ¿Está corriendo?
    if systemctl is-active --quiet nginx; then
        log_success "Nginx está corriendo"
    else
        log_error "Nginx NO está corriendo"
        send_alert "❌ Nginx Down" "Nginx no está ejecutándose en $(hostname)"
        return 1
    fi
    
    # ¿Config válida?
    if sudo nginx -t 2>&1 | grep -q "successful"; then
        log_success "Configuración Nginx válida"
    else
        log_error "Configuración Nginx inválida"
        sudo nginx -t 2>&1 >> "$LOG_FILE"
    fi
    
    # ¿Puerto accesible?
    if curl -f http://localhost:80 > /dev/null 2>&1; then
        log_success "Puerto 80 accesible"
    else
        log_error "Puerto 80 NO accesible"
    fi
    
    # Upstreams
    if [ -d "/etc/nginx/sites-enabled" ]; then
        local upstream_count=$(grep -r "upstream" /etc/nginx/ 2>/dev/null | wc -l)
        log_success "Upstreams configurados: $upstream_count"
    fi
    
    return 0
}

##############################################################################
# Verificaciones Tomcat
##############################################################################

check_tomcat() {
    echo ""
    log_info "Verificando Tomcat..."
    
    local CATALINA_HOME="${CATALINA_HOME:-/opt/tomcat}"
    
    if [ ! -d "$CATALINA_HOME" ]; then
        log_warning "CATALINA_HOME no encontrado: $CATALINA_HOME"
        return 1
    fi
    
    # ¿Está corriendo?
    if pgrep -f "catalina" > /dev/null; then
        log_success "Tomcat está corriendo"
    else
        log_error "Tomcat NO está corriendo"
        send_alert "❌ Tomcat Down" "Tomcat no está ejecutándose en $(hostname)"
        return 1
    fi
    
    # ¿Puerto accesible?
    if curl -f http://localhost:8080 > /dev/null 2>&1; then
        log_success "Puerto 8080 accesible"
    else
        log_error "Puerto 8080 NO accesible"
    fi
    
    # Errores en logs
    local error_count=$(grep -c "ERROR" "$CATALINA_HOME/logs/catalina.out" 2>/dev/null || echo 0)
    if [ "$error_count" -gt 10 ]; then
        log_warning "Múltiples errores en logs ($error_count)"
    else
        log_success "Logs sin errores críticos"
    fi
    
    # Aplicaciones desplegadas
    local apps=$(ls -1d "$CATALINA_HOME/webapps"/*/ 2>/dev/null | wc -l)
    log_success "Aplicaciones desplegadas: $apps"
    
    return 0
}

##############################################################################
# Verificaciones WebLogic
##############################################################################

check_weblogic() {
    echo ""
    log_info "Verificando WebLogic..."
    
    # ¿Está corriendo?
    if pgrep -f "weblogic.Server" > /dev/null; then
        log_success "WebLogic está corriendo"
    else
        log_error "WebLogic NO está corriendo"
        send_alert "❌ WebLogic Down" "WebLogic no está ejecutándose en $(hostname)"
        return 1
    fi
    
    # ¿Puerto accesible?
    if curl -f http://localhost:7001 > /dev/null 2>&1; then
        log_success "Puerto 7001 accesible"
    else
        log_error "Puerto 7001 NO accesible"
    fi
    
    # Memoria JVM
    local pid=$(pgrep -f "weblogic.Server" | head -1)
    if [ -n "$pid" ]; then
        local mem=$(ps aux | grep $pid | awk '{print $6}')
        log_success "Memoria WebLogic: ${mem}KB"
    fi
    
    return 0
}

##############################################################################
# Verificaciones del Sistema
##############################################################################

check_system() {
    echo ""
    log_info "Verificando Sistema..."
    
    # Espacio en disco
    local disk_usage=$(df / | awk 'NR==2 {print $5}' | cut -d'%' -f1)
    if [ "$disk_usage" -gt 85 ]; then
        log_error "Disco al ${disk_usage}% - CRÍTICO"
    elif [ "$disk_usage" -gt 75 ]; then
        log_warning "Disco al ${disk_usage}%"
    else
        log_success "Espacio en disco: ${disk_usage}%"
    fi
    
    # Carga del sistema
    local load=$(uptime | awk '{print $(NF-2)}' | cut -d',' -f1)
    log_success "Carga del sistema: $load"
    
    # Procesos Java
    local java_procs=$(pgrep -f java | wc -l)
    log_success "Procesos Java: $java_procs"
    
    # Memoria disponible
    local mem_avail=$(free -m | awk 'NR==2 {print $7}')
    log_success "Memoria disponible: ${mem_avail}MB"
}

##############################################################################
# Reporte Final
##############################################################################

generate_report() {
    echo ""
    echo -e "${BLUE}════════════════════════════════════════${NC}"
    echo -e "${BLUE}       REPORTE DE HEALTHCHECK${NC}"
    echo -e "${BLUE}════════════════════════════════════════${NC}"
    
    if [ $ISSUES -eq 0 ]; then
        echo -e "${GREEN}✓ TODOS LOS SERVICIOS OPERACIONALES${NC}"
        echo "Timestamp: $TIMESTAMP"
        echo "Hostname: $(hostname)"
    else
        echo -e "${RED}✗ PROBLEMAS DETECTADOS: $ISSUES${NC}"
        echo "Timestamp: $TIMESTAMP"
        echo "Hostname: $(hostname)"
        echo ""
        echo "Revisar log: $LOG_FILE"
    fi
    
    echo -e "${BLUE}════════════════════════════════════════${NC}"
}

##############################################################################
# Main
##############################################################################

main() {
    # Crear log si no existe
    touch "$LOG_FILE"
    
    echo -e "${BLUE}🔍 INICIANDO HEALTHCHECK${NC}"
    echo "Timestamp: $TIMESTAMP"
    echo "Hostname: $(hostname)"
    
    # Ejecutar verificaciones
    check_apache || true
    check_nginx || true
    check_tomcat || true
    check_weblogic || true
    check_system
    
    # Generar reporte
    generate_report
    
    # Retornar código de salida
    exit $ISSUES
}

# Ejecutar main
main "$@"
