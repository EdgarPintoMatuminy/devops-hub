# 🌐 WebLogic - Comandos Diarios

## 📍 Ubicaciones Importantes

```bash
# Instalación
/opt/oracle/
/opt/weblogic/
/u01/oracle/

# Binarios
$MW_HOME/wlserver/bin/
setWLSEnv.sh
startWebLogic.sh
stopWebLogic.sh
wlst.sh (WebLogic Scripting Tool)

# Dominios
$WL_HOME/user_projects/domains/
$DOMAIN_NAME/

# Logs
$DOMAIN_HOME/servers/AdminServer/logs/
$DOMAIN_HOME/servers/*/logs/

# Configuración
$DOMAIN_HOME/config/
config.xml
boot.properties
```

## 🔑 Variables de Entorno

```bash
# Configurar antes de usar
export MW_HOME=/opt/oracle/middleware
export WL_HOME=$MW_HOME/wlserver
export JAVA_HOME=/usr/java/latest
export PATH=$JAVA_HOME/bin:$MW_HOME/wlserver/bin:$PATH

# O sourcing automático
source $MW_HOME/wlserver/server/bin/setWLSEnv.sh
```

## 🚀 Inicio y Parada de Admin Server

```bash
# Iniciar Admin Server (desde DOMAIN_HOME)
cd $DOMAIN_HOME
./bin/startWebLogic.sh

# Con parámetros personalizados
./bin/startWebLogic.sh username=weblogic password=password

# En background
nohup ./bin/startWebLogic.sh > admin_server.log 2>&1 &

# Parar Admin Server
cd $DOMAIN_HOME
./bin/stopWebLogic.sh

# Con fuerza
kill -9 <PID>

# Ver procesos
ps aux | grep "weblogic.Server"
jps -l
```

## 🔰 Managed Servers

```bash
# Iniciar Managed Server
cd $DOMAIN_HOME
./bin/startManagedWebLogic.sh managed_server_name t3://admin_server:7001

# Ejemplo
./bin/startManagedWebLogic.sh MS01 t3://localhost:7001

# Parar Managed Server
./bin/stopManagedWebLogic.sh managed_server_name t3://localhost:7001

# Estado de servidores
# Usar Admin Console o WLST
```

## 📡 WLST (WebLogic Scripting Tool)

```bash
# Iniciar WLST interactivo
$MW_HOME/wlserver/common/bin/wlst.sh

# Ejecutar script WLST
wlst.sh script.py

# Conectar a Admin Server
connect('weblogic','password','t3://localhost:7001')

# Listar servidores
cd('/Servers')
ls()

# Obtener info de servidor
get('Servers/AdminServer')
get('Servers/AdminServer/ListenPort')

# Ver aplicaciones desplegadas
cd('/AppDeployments')
ls()

# Desconectar
disconnect()
exit()
```

## 📦 Deployment de Aplicaciones

```bash
# Vía Console Admin
# http://localhost:7001/console

# Vía WLST - Deploy
connect('weblogic','password','t3://localhost:7001')
deploy(appName='miapp', 
       path='/ruta/a/miapp.war',
       targets='AdminServer')
disconnect()

# Vía WLST - Undeploy
connect('weblogic','password','t3://localhost:7001')
undeploy('miapp')
disconnect()

# Vía WLST - Redeploy
connect('weblogic','password','t3://localhost:7001')
redeploy('miapp', path='/ruta/a/miapp.war')
disconnect()

# Vía línea de comandos
$MW_HOME/wlserver/server/bin/wldeploy.sh \
  -adminurl t3://localhost:7001 \
  -username weblogic \
  -password password \
  -deploy \
  -upload \
  -source /ruta/a/miapp.war \
  -name miapp \
  -targets AdminServer
```

## 🔍 Logs y Troubleshooting

```bash
# Admin Server logs
tail -f $DOMAIN_HOME/servers/AdminServer/logs/AdminServer.log

# Managed Server logs
tail -f $DOMAIN_HOME/servers/MS01/logs/MS01.log

# Logs de salida estándar
tail -f $DOMAIN_HOME/AdminServer.log
tail -f $DOMAIN_HOME/servers/*/logs/*_err.log

# Búsqueda en logs
grep "ERROR" $DOMAIN_HOME/servers/AdminServer/logs/AdminServer.log
grep "SEVERE" $DOMAIN_HOME/servers/AdminServer/logs/AdminServer.log

# Ver últimas líneas
tail -n 200 $DOMAIN_HOME/servers/AdminServer/logs/AdminServer.log | grep -i error

# Estadísticas de logs
wc -l $DOMAIN_HOME/servers/AdminServer/logs/AdminServer.log
du -h $DOMAIN_HOME/servers/AdminServer/logs/
```

## 🛡️ Gestión de Seguridad

```bash
# Cambiar password admin
cd $DOMAIN_HOME
./bin/setUserPassword.sh weblogic newpassword

# Encriptar valores sensibles
java weblogic.security.utils.ValidateKeystore \
     -keystore DefaultIdentity.jks

# Ver usuarios y grupos (WLST)
connect('weblogic','password','t3://localhost:7001')
cd('/SecurityConfiguration/mydomain/Realms/myrealm/AuthenticationProviders')
ls()
```

## 📊 Monitoreo y Performance

```bash
# Monitoreo vía WLST
connect('weblogic','password','t3://localhost:7001')

# Métricas de servidor
cd('/Servers/AdminServer')
get('RunningState')
get('OpenSocketsCurrentCount')
get('ExecuteQueueLength')

# Métricas de JVM
cd('/Servers/AdminServer/JVMRuntime/AdminServer')
get('HeapFreeCurrent')
get('HeapSizeCurrent')
get('HeapSizeMax')
get('TotalGarbageCollectionCount')

# Disconnect
disconnect()

# Monitor console (si está disponible)
# http://localhost:7001/weblogic/server
```

## 🔌 Puertos Comunes

```
AdminServer: 7001 (HTTP), 7002 (HTTPS)
Managed Servers: 7003+
Node Manager: 5556

# Verificar puertos
sudo netstat -tlnp | grep -E "7001|7002|5556"
ss -tlnp | grep -i weblogic
```

## ⚙️ Configuración Importante

```bash
# setDomainEnv.sh - Variables de entorno del dominio
$DOMAIN_HOME/bin/setDomainEnv.sh

# Configurar memoria JVM
# Editar setDomainEnv.sh
export USER_MEM_ARGS="-Xms1024m -Xmx2048m"

# Boot.properties - Credenciales almacenadas
$DOMAIN_HOME/servers/AdminServer/security/boot.properties
# username=weblogic
# password=EncryptedPassword

# Config.xml - Configuración del dominio
$DOMAIN_HOME/config/config.xml
```

## 📝 Crear Script WLST

```python
# deploy_app.py
#!/usr/bin/env python

import sys

adminURL = 't3://localhost:7001'
adminUsername = 'weblogic'
adminPassword = 'password'
appPath = '/ruta/a/miapp.war'
appName = 'miapp'
targets = 'AdminServer'

try:
    connect(adminUsername, adminPassword, adminURL)
    deploy(appName=appName, path=appPath, targets=targets)
    print('Aplicacion desplegada exitosamente')
except Exception, e:
    print('Error al desplegar: ' + str(e))
finally:
    disconnect()
    exit()
```

```bash
# Ejecutar script
wlst.sh deploy_app.py
```

## 🔍 Diagnóstico Avanzado

```bash
# Thread dump
jstack $(jps -l | grep "weblogic.Server" | awk '{print $1}')

# Heap dump
jmap -dump:live,format=b,file=heap.bin $(jps -l | grep weblogic | awk '{print $1}')

# Ver clases cargadas
jmap -permstat $(jps -l | grep weblogic | awk '{print $1}')

# GC log (activar en boot.properties)
export JAVA_OPTIONS="-verbose:gc -XX:+PrintGCTimeStamps -Xloggc:gc.log"
```

## 📌 Checklist Diario

- [ ] ¿Admin Server running? `ps aux | grep weblogic.Server`
- [ ] ¿Managed Servers running? `ps aux | grep weblogic`
- [ ] ¿Console accesible? `curl http://localhost:7001/console`
- [ ] ¿Apps desplegadas OK? `wlst.sh` -> `connect()` -> `ls()` en AppDeployments
- [ ] ¿Sin errores en logs? `grep -i "error" *AdminServer*.log`
- [ ] ¿Memoria JVM OK? `jstat -gc $(jps -l | grep weblogic | awk '{print $1}')`
- [ ] ¿Puertos escuchando? `netstat -tlnp | grep 7001`

## 🚨 Troubleshooting Común

```bash
# Port en uso
netstat -tlnp | grep 7001
kill -9 <PID>

# Permisos incorrectos
chmod +x $DOMAIN_HOME/bin/*.sh
chmod -R 755 $DOMAIN_HOME

# Node Manager no responde
$MW_HOME/wlserver/server/bin/startNodeManager.sh

# Sincronizar dominio
cd $DOMAIN_HOME
./bin/startWebLogic.sh -Dweblogic.management.discover=true

# Limpiar estado de aplicación
rm -rf $DOMAIN_HOME/servers/AdminServer/cache
rm -rf $DOMAIN_HOME/servers/AdminServer/tmp
```

---

**Última actualización:** Julio 2026  
**Referencia:** Oracle WebLogic Server 12c Documentation
