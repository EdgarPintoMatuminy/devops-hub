# 🔧 Apache - Comandos Diarios

## 📍 Ubicaciones Importantes

```bash
# Configuración principal
/etc/apache2/apache2.conf
/etc/apache2/sites-enabled/

# Logs
/var/log/apache2/access.log
/var/log/apache2/error.log

# Binario
/usr/sbin/apache2
/usr/sbin/apachectl
```

## 🚀 Inicio y Parada

```bash
# Iniciar Apache
sudo systemctl start apache2
sudo service apache2 start

# Parar Apache
sudo systemctl stop apache2
sudo service apache2 stop

# Reiniciar
sudo systemctl restart apache2

# Recarga de configuración (sin interrumpir conexiones)
sudo systemctl reload apache2
sudo apachectl graceful

# Estado
sudo systemctl status apache2
sudo apachectl fullstatus
```

## ✅ Verificación de Configuración

```bash
# Syntax check
sudo apachectl configtest
sudo apache2ctl -t

# Ver configuración de sitios activos
sudo apache2ctl -S

# Ver módulos cargados
sudo apache2ctl -M
```

## 📦 Gestión de Módulos

```bash
# Habilitar módulo
sudo a2enmod nombre_modulo

# Deshabilitar módulo
sudo a2dismod nombre_modulo

# Módulos más comunes
sudo a2enmod proxy
sudo a2enmod proxy_http
sudo a2enmod rewrite
sudo a2enmod ssl
sudo a2enmod headers
sudo a2enmod cache

# Listar módulos habilitados
sudo apache2ctl -M
```

## 🌐 Gestión de Sitios

```bash
# Habilitar sitio
sudo a2ensite nombre_sitio

# Deshabilitar sitio
sudo a2dissite nombre_sitio

# Listar sitios disponibles y habilitados
ls /etc/apache2/sites-available/
ls /etc/apache2/sites-enabled/

# Crear y habilitar nuevo sitio
sudo cp /etc/apache2/sites-available/000-default.conf /etc/apache2/sites-available/miapp.conf
sudo a2ensite miapp
sudo systemctl reload apache2
```

## 📝 Configuración Proxy Reverso

```apache
# /etc/apache2/sites-available/proxy.conf
<VirtualHost *:80>
    ServerName ejemplo.com
    
    ProxyPreserveHost On
    ProxyPass / http://localhost:8080/
    ProxyPassReverse / http://localhost:8080/
    
    # Headers
    ProxyPass / http://backend:8080/
    ProxyPassReverse / http://backend:8080/
    RequestHeader set X-Forwarded-Proto "http"
</VirtualHost>
```

## 🔍 Logs y Troubleshooting

```bash
# Ver logs en tiempo real
sudo tail -f /var/log/apache2/access.log
sudo tail -f /var/log/apache2/error.log

# Ver últimas N líneas
sudo tail -n 50 /var/log/apache2/error.log

# Búsqueda en logs
grep "ERROR" /var/log/apache2/error.log
grep "500" /var/log/apache2/access.log

# Estadísticas de IPs
awk '{print $1}' /var/log/apache2/access.log | sort | uniq -c | sort -rn

# Errores 404
grep "404" /var/log/apache2/access.log | awk '{print $7}' | sort | uniq -c
```

## 🛡️ SSL/TLS

```bash
# Habilitar módulo SSL
sudo a2enmod ssl

# Crear certificado autofirmado
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout /etc/ssl/private/server.key \
  -out /etc/ssl/certs/server.crt

# Configurar SSL en VirtualHost
<VirtualHost *:443>
    ServerName ejemplo.com
    
    SSLEngine on
    SSLCertificateFile /etc/ssl/certs/server.crt
    SSLCertificateKeyFile /etc/ssl/private/server.key
</VirtualHost>
```

## 🎯 Performance

```bash
# Monitoreo de conexiones activas
sudo netstat -an | grep ESTABLISHED | wc -l

# Procesos Apache
ps aux | grep apache2

# Uso de memoria
ps aux | grep apache2 | awk '{sum+=$6} END {print sum/1024 "MB"}'
```

## 📊 Estadísticas (mod_status)

```bash
# Habilitar módulo status
sudo a2enmod status

# Configurar en apache2.conf
<Location /server-status>
    SetHandler server-status
</Location>

# Acceder
curl http://localhost/server-status
```

## 🐛 Debugging

```bash
# Aumentar nivel de log
# En apache2.conf o sitio
LogLevel debug

# Recarga para que tenga efecto
sudo systemctl reload apache2

# Ver logs detallados
tail -f /var/log/apache2/error.log

# Volver a nivel normal
LogLevel warn
```

## 📌 Checklist de Troubleshooting

- [ ] ¿Apache está corriendo? `systemctl status apache2`
- [ ] ¿Puertos correctos? `sudo netstat -tlnp | grep apache`
- [ ] ¿Configuración correcta? `apachectl configtest`
- [ ] ¿Permisos de archivos? `ls -la /var/www/`
- [ ] ¿Módulos necesarios habilitados? `apache2ctl -M`
- [ ] ¿Firewall bloqueando? `sudo ufw status`
- [ ] ¿Logs sin errores? `tail -f /var/log/apache2/error.log`

---

**Última actualización:** Julio 2026
