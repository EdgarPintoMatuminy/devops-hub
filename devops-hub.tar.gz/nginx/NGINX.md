# ⚡ Nginx - Comandos Diarios

## 📍 Ubicaciones Importantes

```bash
# Configuración principal
/etc/nginx/nginx.conf
/etc/nginx/sites-enabled/
/etc/nginx/conf.d/

# Logs
/var/log/nginx/access.log
/var/log/nginx/error.log

# Binario
/usr/sbin/nginx
```

## 🚀 Inicio y Parada

```bash
# Iniciar Nginx
sudo systemctl start nginx
sudo service nginx start

# Parar Nginx
sudo systemctl stop nginx

# Reiniciar
sudo systemctl restart nginx

# Recarga de configuración (sin interrumpir)
sudo systemctl reload nginx
sudo nginx -s reload

# Estado
sudo systemctl status nginx
sudo service nginx status
```

## ✅ Verificación de Configuración

```bash
# Syntax check
sudo nginx -t
sudo nginx -T  # Muestra configuración procesada

# Ver procesos
ps aux | grep nginx

# Verificar puertos
sudo netstat -tlnp | grep nginx
sudo ss -tlnp | grep nginx
```

## 🌐 Gestión de Configuración

```bash
# Ver sitios habilitados
ls -la /etc/nginx/sites-enabled/

# Ver sitios disponibles
ls -la /etc/nginx/sites-available/

# Habilitar sitio
sudo ln -s /etc/nginx/sites-available/miapp /etc/nginx/sites-enabled/
sudo systemctl reload nginx

# Deshabilitar sitio
sudo rm /etc/nginx/sites-enabled/miapp
sudo systemctl reload nginx
```

## 📡 Proxy Reverso Básico

```nginx
# /etc/nginx/sites-available/reverse-proxy

upstream backend {
    server 127.0.0.1:8080;
    server 127.0.0.1:8081;
    server 127.0.0.1:8082;
}

server {
    listen 80;
    server_name ejemplo.com;
    
    location / {
        proxy_pass http://backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

## ⚖️ Load Balancing

```nginx
# Round-robin (defecto)
upstream app {
    server app1:8080;
    server app2:8080;
    server app3:8080;
}

# Weighted (con pesos)
upstream app_weighted {
    server app1:8080 weight=3;
    server app2:8080 weight=1;
}

# IP Hash (sticky sessions)
upstream app_hash {
    ip_hash;
    server app1:8080;
    server app2:8080;
}

# Least Connections
upstream app_least {
    least_conn;
    server app1:8080;
    server app2:8080;
}

# Health checks
upstream app_health {
    server app1:8080 max_fails=3 fail_timeout=30s;
    server app2:8080 max_fails=3 fail_timeout=30s;
    server backup_app:8080 backup;
}
```

## 🔍 Logs y Troubleshooting

```bash
# Ver logs en tiempo real
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log

# Filtrar por código de error
grep "500" /var/log/nginx/access.log
grep "404" /var/log/nginx/access.log

# Estadísticas de IPs
awk '{print $1}' /var/log/nginx/access.log | sort | uniq -c | sort -rn

# Búsqueda en logs
grep "upstream timed out" /var/log/nginx/error.log

# Performance - peticiones por segundo
tail -1000 /var/log/nginx/access.log | wc -l

# Top de rutas solicitadas
awk '{print $7}' /var/log/nginx/access.log | sort | uniq -c | sort -rn | head -20
```

## 🛡️ SSL/TLS

```nginx
server {
    listen 443 ssl http2;
    server_name ejemplo.com;
    
    ssl_certificate /etc/ssl/certs/server.crt;
    ssl_certificate_key /etc/ssl/private/server.key;
    
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;
}

# Redirigir HTTP a HTTPS
server {
    listen 80;
    server_name ejemplo.com;
    return 301 https://$server_name$request_uri;
}
```

## 📦 Compresión y Caché

```nginx
# Compresión GZIP
gzip on;
gzip_types text/plain text/css text/javascript 
           application/javascript application/json;
gzip_min_length 1000;
gzip_comp_level 6;

# Caché
location ~* \.(jpg|jpeg|png|gif|ico|css|js)$ {
    expires 7d;
    add_header Cache-Control "public, immutable";
}
```

## 🎯 Rate Limiting

```nginx
# Límite de conexiones
limit_conn_zone $binary_remote_addr zone=conn_limit:10m;
limit_conn conn_limit 10;

# Límite de peticiones
limit_req_zone $binary_remote_addr zone=req_limit:10m rate=10r/s;
limit_req zone=req_limit burst=20 nodelay;
```

## 📊 Estadísticas

```bash
# Conexiones activas
ss -an | grep ESTABLISHED | wc -l

# Procesos Nginx
ps aux | grep nginx

# Uso de recursos
top -p $(pgrep -f nginx | tr '\n' ',')

# Memoria total
ps aux | grep nginx | awk '{sum+=$6} END {print sum "KB"}'
```

## 🔐 Headers de Seguridad

```nginx
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-Content-Type-Options "nosniff" always;
add_header X-XSS-Protection "1; mode=block" always;
add_header Referrer-Policy "no-referrer-when-downgrade" always;
add_header Content-Security-Policy "default-src 'self'" always;
```

## ⚙️ Optimización

```nginx
# Workers
worker_processes auto;

# Conexiones
events {
    worker_connections 4096;
    use epoll;
}

# Timeouts
proxy_connect_timeout 60s;
proxy_send_timeout 60s;
proxy_read_timeout 60s;
client_max_body_size 100m;
```

## 🐛 Debugging

```bash
# Debug mode (compilar con --with-debug)
sudo nginx -g "daemon off;" # En foreground

# Verbose logging en error.log
# Editar /etc/nginx/nginx.conf
error_log /var/log/nginx/error.log debug;

# Recarga
sudo systemctl reload nginx

# Ver en logs detallados
tail -f /var/log/nginx/error.log
```

## 📌 Checklist Diario

- [ ] ¿Nginx está running? `systemctl status nginx`
- [ ] ¿Config válida? `nginx -t`
- [ ] ¿Puertos correctos? `netstat -tlnp | grep nginx`
- [ ] ¿Backend disponible? `curl http://backend:8080`
- [ ] ¿Logs sin errores? `tail /var/log/nginx/error.log`
- [ ] ¿Load balancing funcionando? `tail /var/log/nginx/access.log`
- [ ] ¿SSL válido? `openssl s_client -connect localhost:443`

---

**Última actualización:** Julio 2026
